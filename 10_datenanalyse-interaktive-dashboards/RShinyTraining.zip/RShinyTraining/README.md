# Interaktive Dashboards 

## Lizenzinformationen

## Inhaltlicher Input

[![License: CC BY 4.0](https://img.shields.io/badge/License-CC%20BY%204.0-lightgrey.svg)](https://creativecommons.org/licenses/by/4.0/deed.de)

Folien sind lizensiert unter [Creative Commons Attribution 4.0 International](https://creativecommons.org/licenses/by/4.0/legalcode.de). Attribution ist in der folgenden Form erfolgen:

"Programmieraufgabe oder Lückentext? Wir visualisieren Daten und automatisieren Reports (für Anfänger:innen)", verfügbar unter [Link zu den Folien], Nina Hauser, lizensiert unter [Creative Commons Attribution 4.0 International](https://creativecommons.org/licenses/by/4.0/legalcode.de).

Alternativ kann der Link zu den Folien auch als Hyperlink dem Titel hinzugefügt werden.

## Code
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Code in `.R` und `.Rmd` Dateien ist lizensiert unter der MIT Lizenz.